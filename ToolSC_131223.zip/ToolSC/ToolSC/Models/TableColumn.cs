﻿namespace ToolSC.Models
{
    public class TableColumn
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string Length { get; set; }
        public string Data { get; set; }
    }
}
