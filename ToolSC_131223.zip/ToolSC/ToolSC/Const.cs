﻿namespace ToolSC
{
    public class Const
    {
        public const string SITE_CODE_KEY = "拠点コード";
        public const string DEFAULT_SITE_CODE = "9993273";

        public const string DATE_CHAR = "日";
        public const string TIME_CHAR = "時刻";

        public const string DATE_VAR_LENGTH = "8";
        public const string TIME_VAR_LENGTH = "6";
    }
}
